# School Management System PHP & MYSQL

version: 1.0.0

## TECHNOLOGIES

1. PHP
1. MYSQL
1. BOOTSTRAP 5
1. HTML
1. CSS
1. JS

## Full Tutorial

[On Youtube](https://youtube.com/playlist?list=PL2WFgdVk-usEEEPk5dfgg_fvUeGDM8NWf)

## Authors

[Elias Abdurrahman](https://github.com/codingWithElias)
