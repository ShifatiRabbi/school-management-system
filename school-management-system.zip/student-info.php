<?php 
include "header.php";
?>

<h3 class="mt-5 mb-3" style="text-align: center;"> Student Info Comming Soon</h3>
<h4 class="mb-5" style="text-align: center;"> Stay With US</h4>

<div class="mb-5" style="justify-self: center;">
    <a href="index.php" class="btn btn-outline-primary">Go Back Home</a>
</div>

<?php 
include "footer.php";
?>